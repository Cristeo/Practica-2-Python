Numero1 = int(input("Dame un numero entero: "))
Numero2 = int(input("Dame un numero entero: "))

if Numero2 != 0 and Numero1 % Numero2 == 0:
    print (Numero1 ,"Es divisible entre: ", Numero2 )
else:
    print (Numero1 ,"No es divisible entre: ", Numero2 )
    
