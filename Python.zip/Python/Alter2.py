N1 = int(input("Dame tu numero: "))
N2 = int(input("Dame otro numero: "))

if N1 < N2:
    print("El menor es:", N1, "y el mayor es:", N2)
else:
    print("El menor es:", N2, "y el mayor es:", N1)
