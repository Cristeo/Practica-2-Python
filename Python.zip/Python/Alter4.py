L = input("Dame letra: ").lower()

if L in ("a", "e", "i", "o", "u"):
    print("Es una vocal:", L)
else:
    print("Consonante:", L)