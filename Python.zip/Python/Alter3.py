N = int(input("Dame tu numero: "))

if N > 0:
    print ("Positivo")
elif N< 0:
    print ("negativo")
else : print ("nulo")
