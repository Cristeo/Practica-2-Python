#Programa de longitud en pulgadas
longitud = int(input("Dame una longitud: "))
pulgadas = longitud/2.54
print ("La longitud es en pulgadas: ", pulgadas)