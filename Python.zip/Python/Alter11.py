print("1. Sumar\n2. Restar\n3. Multiplicar\n4. Dividir\n5. Resto")
opcion = input("Elige una opción: ")

Numero1 = int(input("Dame un numero: "))
Numero2 = int(input("Dame otro numero: "))

if opcion == "1":
    print("Suma:", Numero1 + Numero2)
elif opcion == "2":
    print("Resta:", Numero1 - Numero2)
elif opcion == "3":
    print("Multiplicación:", Numero1 * Numero2)
elif opcion == "4":
    if Numero2 != 0:
        print("División:", Numero1 / Numero2)
    else:
        print("No se puede dividir entre 0")
elif opcion == "5":
    if Numero2 != 0:
        print("Resto:", Numero1 % Numero2)
    else:
        print("No se puede dividir entre 0")
else:
    print("Opción no válida")
