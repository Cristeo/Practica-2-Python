N = int(input("Dame tu nota: "))

if N >= 5:
    print ("Aprobado")
else :
    print ("suspenso")
