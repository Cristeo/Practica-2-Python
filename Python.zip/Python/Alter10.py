Numero1 = float(input("Introduce tu nota: "))

if Numero1 < 5:
    print("Suspenso")
elif Numero1 < 6:
    print("Suficiente")
elif Numero1 < 7:
    print("Bien")
elif Numero1 < 9:
    print("Notable")
else:
    print("Sobresaliente")
