Numero1 = int(input("Dame un numero: "))
Numero2 = int(input("Dame un numero: "))
Numero3 = int(input("Dame un numero: "))

if Numero1 == Numero2 == Numero3:
    print("El triangulo es equilatero")

else :
    print("El triangulo no es equilatero")