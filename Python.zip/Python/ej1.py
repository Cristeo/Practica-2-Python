#calculadora de circulo
import math
r = float(input("Dame un radio: "))
area = math.pi * r**2
print(f"El área es: {area:.2f}")
