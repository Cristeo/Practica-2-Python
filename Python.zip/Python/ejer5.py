#Coeficientes
CoeficienteA = float(input("Dame un coeficiente: "))
CoeficienteB = float(input("Dame otro coeficiente: "))
x = -CoeficienteB / CoeficienteA
print("El resultado es:", x)