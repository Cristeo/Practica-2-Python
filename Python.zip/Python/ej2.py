#Calculadora area de rectangulo
base = int(input("Dame una base: "))
altura= int (input("Dame una altura: "))
area= base*altura
print ("El area es: ", area)


#test