Numero1 = int(input("Dame un numero: "))
Numero2 = int(input("Dame un numero: "))
Numero3 = int(input("Dame un numero: "))

if Numero1 == Numero2 == Numero3:
    print("El triangulo es equilatero")
elif Numero1 == Numero2 or Numero2 == Numero3 or Numero1 == Numero3:
    print("El triangulo es Isoceles")
else :
    print("El triangulo es escaleno")