import math
a = float(input("Dame a: "))
b = float(input("Dame b: "))
c = float(input("Dame c: "))

d = b**2 - 4*a*c
if a == 0:
    print("a no puede ser 0")
elif d >= 0:
    x1 = (-b + math.sqrt(d)) / (2*a)
    x2 = (-b - math.sqrt(d)) / (2*a)
    print("x1 =", x1)
    print("x2 =", x2)
else:
    print("No tiene raíces reales")