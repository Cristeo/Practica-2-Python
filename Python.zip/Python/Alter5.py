import math
letra = input("Dame una letra: ")
if letra == "A":
    r = float(input("Dame un radio: "))
    area = math.pi * r ** 2
    print("El area de la circunferencia es: ",area)

elif letra == "L":
    r = float(input("Dame radio: "))
    longitud = 2* math.pi * r
    print("La longitud de la circunferencia es:", longitud)

else:
    print ("No valida ")