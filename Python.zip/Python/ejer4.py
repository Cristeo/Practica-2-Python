#Triangulo rectangulo
import math

cateto_1 = float(input("Dame el valor del cateto 1: "))
cateto_2 = float(input("Dame el valor del cateto 2: "))
hipotenusa = math.sqrt(cateto_1**2 + cateto_2**2)
print ("La hipotenusa es: ", hipotenusa)